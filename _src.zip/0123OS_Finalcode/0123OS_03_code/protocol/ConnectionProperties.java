package org.learningredis.chapter.three.protocol;

public interface ConnectionProperties {
	public String host="localhost";
	public int   port =6379;
}
