package redisch8;

import vinoo.util.common.ReturnValue;

public interface ReadProperties
{
    ReturnValue hget(String string);
}
